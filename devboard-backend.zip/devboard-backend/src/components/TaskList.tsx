import { useEffect, useState } from "react";
import api from "../api";

interface Task {
    id: number;
    title: string;
    status: string;
}

export default function TaskList({ reload }: { reload: boolean }) {
    const [tasks, setTasks] = useState<Task[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const fetchTasks = async () => {
        setLoading(true);
        try {
            const res = await api.get("/tasks");
            setTasks(res.data);
            setError("");
        } catch (err) {
            setError("Failed to load tasks.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTasks();
    }, [reload]);

    if (loading) return <p>Loading tasks...</p>;
    if (error) return <p style={{ color: "red" }}>{error}</p>;

    return (
        <ul>
            {tasks.map((task) => (
                <li key={task.id}>
                    <strong>{task.title}</strong> — {task.status}
                </li>
            ))}
        </ul>
    );
}
