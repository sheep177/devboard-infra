import { useState } from "react";
import api from "../api";

interface Task {
    title: string;
    status: string;
}

export default function TaskForm({ onTaskCreated }: { onTaskCreated: () => void }) {
    const [task, setTask] = useState<Task>({ title: "", status: "ToDo" });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setTask({ ...task, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {
            await api.post("/tasks", task);
            setTask({ title: "", status: "ToDo" });
            onTaskCreated(); // 通知父组件刷新任务列表
        } catch (err) {
            setError("Failed to create task");
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{ marginBottom: "1rem" }}>
            <div>
                <input
                    type="text"
                    name="title"
                    value={task.title}
                    onChange={handleChange}
                    placeholder="Enter task title"
                    required
                />
            </div>
            <div>
                <select name="status" value={task.status} onChange={handleChange}>
                    <option value="ToDo">ToDo</option>
                    <option value="InProgress">InProgress</option>
                    <option value="Done">Done</option>
                </select>
            </div>
            <button type="submit" disabled={loading}>
                {loading ? "Creating..." : "Create Task"}
            </button>
            {error && <p style={{ color: "red" }}>{error}</p>}
        </form>
    );
}
