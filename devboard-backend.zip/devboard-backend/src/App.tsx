import { useEffect, useState } from "react";
import api from "./api";

interface Task {
    id: number;
    title: string;
    status: string;
}

function App() {
    const [tasks, setTasks] = useState<Task[]>([]);

    useEffect(() => {
        api.get<Task[]>("/tasks")
            .then(res => setTasks(res.data))
            .catch(err => console.error("Failed to fetch tasks", err));
    }, []);

    return (
        <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
            <h1>🗂 DevBoard - Task List</h1>
            {tasks.length === 0 ? (
                <p>No tasks found.</p>
            ) : (
                <ul>
                    {tasks.map(task => (
                        <li key={task.id}>
                            <strong>{task.title}</strong> — {task.status}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

export default App;
